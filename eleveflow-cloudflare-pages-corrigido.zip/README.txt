ELEVEFLOW — PÁGINA COMERCIAL (VERSÃO DEMONSTRATIVA)

Publicação: extraia o ZIP e envie TODOS os arquivos no mesmo nível (raiz) do projeto Cloudflare Pages via Direct Upload.
Não precisa de Node, npm ou build.

CTA: links de WhatsApp configurados com o número público da Eleve One (37) 99801-4747.

As telas de extrator, pipeline, automação e o painel são DEMONSTRAÇÕES VISUAIS com dados fictícios.
A busca local e o arrastar dos cards NÃO acessam o CRM real nem qualquer banco de dados.
As estatísticas são ILUSTRATIVAS, não resultados comprovados dos clientes.
Nenhum dado pessoal ou telefone de clientes mostrado nos screenshots originais foi incluído.
Os filtros Com Site e Sem Site não aparecem na versão da página comercial.

ANTES DE PUBLICAR NO DOMÍNIO DEFINITIVO
1. Remover o meta robots noindex do index.html.
2. Informar o domínio final e adicionar canonical, og:url e og:image com URLs absolutas.
3. Adicionar robots.txt e sitemap.xml com o domínio DEFINITIVO, registrar no Google Search Console.
4. Criar uma imagem social real 1200x630 e referenciá-la em og:image.
5. Validar o número comercial e textos antes de lançar campanhas de anúncios.

HTML/CSS/JS puro. Conteúdo responsivo, sem dependências de build.

OTIMIZAÇÕES DE CARREGAMENTO (17/10/2026)
- CSS de fontes externas carregado sem bloquear a primeira renderização.
- Menos variações de peso de fontes solicitadas ao Google.
- Hero visível imediatamente (sem fade inicial).
- Eliminado atraso artificial de 430 ms na demonstração do extrator.
- Efeitos de blur decorativo simplificados e backdrop-filter desligado no mobile.
- Manutenção dos botões de segmentos Materiais de construção / Academias.

IMPORTANTE: o arquivo estático é leve, mas testes de velocidade reais devem ser feitos
após publicação no domínio definitivo, pela aba Network e Lighthouse/Pagespeed.
Para testar localmente, EXTRAIA TODOS OS ARQUIVOS do ZIP para uma pasta antes de abrir index.html.
Não abra apenas index.html diretamente pelo WinRAR: ele usa a pasta temporária Rar$EXa.*.
